#!/bin/sh

PID_FILE="serve_pids.txt"

if [ ! -f $PID_FILE ]; then
    echo "Cannot find file $PID_FILE"
    return 1
fi

while IFS= read -r PID; do
    if kill -0 $PID 2>/dev/null; then
        kill $PID
        echo "Server with PID $PID stoped."
    else
        echo "No processus with PID $PID found."
    fi
done < $PID_FILE

rm $PID_FILE

